# La Mujer con Chalina — V1

Prototipo web estático en español para probar una experiencia narrativa interactiva.

## Contenido

- `index.html`: aplicación completa (HTML, CSS y JavaScript). No requiere dependencias ni proceso de compilación.

## Probar localmente

Abre `index.html` en un navegador moderno. También puedes usar la extensión Live Server de Visual Studio Code.

## Publicar con GitHub Pages

1. Crea un repositorio en GitHub, por ejemplo `la-mujer-con-chalina-v1`.
2. Sube el contenido de esta carpeta a la raíz del repositorio.
3. En GitHub, entra en **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/ (root)`, y guarda.
6. Espera a que GitHub Pages publique el sitio. La URL aparecerá en esa misma sección.

## Limitaciones de esta versión

- Es una demostración estática; no genera una imagen personalizada con IA.
- Las respuestas no se envían a un servidor ni se almacenan centralmente. Al finalizar, cada participante descarga un archivo JSON con su feedback y debe entregártelo por un canal que tú indiques.
- No solicita ni necesita fotografías.
- No debe utilizarse para recopilar información sensible. Antes de invitar participantes, explícales el propósito de la prueba y cómo compartirán el archivo de feedback.

## Privacidad

La aplicación no incluye analítica, cookies propias, backend ni transmisión de respuestas. El feedback se genera localmente en el navegador y se descarga como archivo JSON.
